<?php
require_once("model.php");
class nguoidung extends Model
{
    var $table = "nguoidung";
    var $contens = "MaND";
    var $contens1 = "Email";
}