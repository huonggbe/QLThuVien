<?php
require_once("model.php");
class Banner extends Model
{
    var $table = "banner";
    var $contens = "Id";
}