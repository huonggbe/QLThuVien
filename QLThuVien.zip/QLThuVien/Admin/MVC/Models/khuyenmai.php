<?php
require_once("model.php");
class khuyenmai extends Model
{
    var $table = "khuyenmai";
    var $contens = "MaKM";
}