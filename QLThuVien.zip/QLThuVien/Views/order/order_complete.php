<!-- pages-title-start -->
<div class="pages-title section-padding">
	<div class="container">
		<div class="row">
			<div class="col-xs-12">
				<div class="pages-title-text text-center">
					<h2>Mượn sách thành công</h2>
					<ul class="text-left">
						<li><a href="index.php?act=home">Trang chủ</a></li>
						<li><span> / </span>HOÀN THÀNH MƯỢN SÁCH</li>
					</ul>
				</div>
			</div>
		</div>
	</div>
</div>
<!-- pages-title-end -->
<!-- order-complete content section start -->
<section class="pages checkout order-complete section-padding">
	<div class="container">
		<div class="row">
			<div class="col-xs-12 text-center">
				<div class="complete-title">
					<p style="    background: #34aebb;
    color: white;">Xin vui lòng đến quầy sách để chờ</p>
					<p>Tài liệu của bạn đang chờ xét duyệt</p>
				</div>
			</div>
		</div>

	</div>
</section>
<!-- order-complete content section end -->
<?php

unset($_SESSION['sanpham']);
unset($_SESSION['TongTien']);
?>