<!-- pages-title-start -->
<div class="pages-title section-padding">
	<div class="container">
		<div class="row">
			<div class="col-xs-12">
				<div class="pages-title-text text-center">
					<h2></h2>
					<ul class="text-left">
						<li><a href="?act=taikhoan">Trang chủ</a></li>
						<li><span> / </span>404</li>
					</ul>
				</div>
			</div>
		</div>
	</div>
</div>
<!-- pages-title-end -->
<!-- 404 content section start -->
<div class="pages error-page section-padding">
	<div class="container text-center">
		<div class="error-content">
			<img src="public/img/error.png" alt="" />
			<h4>Không tìm thấy trang</h4>
			<p>Xin lỗi, Chúng tôi không thể tìm thấy thông tin về trang này</p>
			
			<a href="?act=home" style = "    background: #fe5858 none repeat scroll 0 0;
    color: #fff;">Trở về trang chủ</a>
		</div>
	</div>
</div>
<!-- 404 content section end -->