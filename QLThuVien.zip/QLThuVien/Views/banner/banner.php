<div class="slider-banner">
<div id="myCarousel" class="carousel slide" data-ride="carousel">
<!-- Indicators -->
<ol class="carousel-indicators">
<li data-target="#myCarousel" data-slide-to="0" class="active"></li>
<li data-target="#myCarousel" data-slide-to="1"></li>

</ol>

<!-- Wrapper for slides -->
<div class="carousel-inner">
<div class="item active slide1">
<img src="VD/img/slide-1.jpg" alt="holiwood">
<div class="carousel-caption">

<h1>BOOK<br>STORE</h1>
<a href="#">Mua ngay</a>
</div>
</div>

<div class="item slide2">
<img src="VD/img/slide-2.jpg" alt="holiwood">
<div class="carousel-caption">  
<h1>SÁCH<br>MỚI</h1>
<h2>Sách hay mới cập nhật</h2>
<a href="#">Mua ngay</a>
</div>
</div>



</div> 
</div>
</div>
